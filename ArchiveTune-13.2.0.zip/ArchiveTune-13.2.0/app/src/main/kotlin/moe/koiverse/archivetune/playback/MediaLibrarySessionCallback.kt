/*
 * ArchiveTune Project Original (2026)
 * Chartreux Westia (github.com/koiverse)
 * Licensed Under GPL-3.0 | see git history for contributors
 * Don't remove this copyright holder!
 */




package moe.koiverse.archivetune.playback

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.annotation.DrawableRes
import androidx.core.net.toUri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.offline.Download
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionError
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import moe.koiverse.archivetune.R
import moe.koiverse.archivetune.constants.MediaSessionConstants
import moe.koiverse.archivetune.constants.SongSortType
import moe.koiverse.archivetune.db.MusicDatabase
import moe.koiverse.archivetune.db.entities.PlaylistEntity
import moe.koiverse.archivetune.db.entities.Song
import moe.koiverse.archivetune.innertube.YouTube
import moe.koiverse.archivetune.innertube.models.SongItem
import moe.koiverse.archivetune.extensions.toMediaItem
import moe.koiverse.archivetune.extensions.toggleRepeatMode
import moe.koiverse.archivetune.models.PersistQueue
import moe.koiverse.archivetune.playback.MusicService.Companion.PERSISTENT_QUEUE_FILE
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.guava.future
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.withContext
import javax.inject.Inject
import kotlin.math.min
import java.io.ObjectInputStream
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MediaLibrarySessionCallback
@Inject
constructor(
    @ApplicationContext val context: Context,
    val database: MusicDatabase,
    val downloadUtil: DownloadUtil,
) : MediaLibrarySession.Callback {
    private val scope = CoroutineScope(Dispatchers.Main) + Job()
    private var pendingSearchJob: Job? = null
    private val onlineSearchItemCache = ConcurrentHashMap<String, MediaItem>()
    var toggleLike: () -> Unit = {}
    var toggleStartRadio: () -> Unit = {}
    var toggleLibrary: () -> Unit = {}

    private fun browsableExtras(
        browsableHint: Int = CONTENT_STYLE_GRID_ITEM,
        playableHint: Int = CONTENT_STYLE_LIST_ITEM,
    ) = Bundle().apply {
        putBoolean(EXTRA_CONTENT_STYLE_SUPPORTED, true)
        putInt(EXTRA_CONTENT_STYLE_BROWSABLE_HINT, browsableHint)
        putInt(EXTRA_CONTENT_STYLE_PLAYABLE_HINT, playableHint)
    }

    private fun playableExtras(
        playableHint: Int = CONTENT_STYLE_LIST_ITEM,
    ) = Bundle().apply {
        putBoolean(EXTRA_CONTENT_STYLE_SUPPORTED, true)
        putInt(EXTRA_CONTENT_STYLE_PLAYABLE_HINT, playableHint)
    }

    override fun onConnect(
        session: MediaSession,
        controller: MediaSession.ControllerInfo,
    ): MediaSession.ConnectionResult {
        val connectionResult = super.onConnect(session, controller)
        return MediaSession.ConnectionResult.accept(
            connectionResult.availableSessionCommands
                .buildUpon()
                .add(MediaSessionConstants.CommandToggleLike)
                .add(MediaSessionConstants.CommandToggleStartRadio)
                .add(MediaSessionConstants.CommandToggleLibrary)
                .add(MediaSessionConstants.CommandToggleShuffle)
                .add(MediaSessionConstants.CommandToggleRepeatMode)
                .build(),
            connectionResult.availablePlayerCommands,
        )
    }

    override fun onPlaybackResumption(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo,
    ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> =
        onPlaybackResumption(mediaSession, controller, true)

    override fun onPlaybackResumption(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo,
        isForPlayback: Boolean,
    ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> =
        scope.future {
            val player = mediaSession.player
            val currentItems = List(player.mediaItemCount) { index -> player.getMediaItemAt(index) }
            val persistedItems =
                withContext(Dispatchers.IO) {
                    readPersistentQueue()?.let { queue ->
                        PlaybackResumptionPlanner.PersistedItems(
                            items = queue.items.map { it.toMediaItem() },
                            mediaItemIndex = queue.mediaItemIndex,
                            positionMs = queue.position,
                        )
                    }
                }
            val result =
                PlaybackResumptionPlanner.resolve(
                    currentItems = currentItems,
                    currentIndex = player.currentMediaItemIndex,
                    currentPositionMs = player.currentPosition,
                    persistedItems = persistedItems,
                    isForPlayback = isForPlayback,
                )
            MediaSession.MediaItemsWithStartPosition(
                result.items,
                result.startIndex,
                result.startPositionMs,
            )
        }

    private fun readPersistentQueue(): PersistQueue? {
        val file = context.filesDir.resolve(PERSISTENT_QUEUE_FILE)
        if (!file.exists() || !file.isFile) return null
        return try {
            file.inputStream().use { fis ->
                ObjectInputStream(fis).use { input ->
                    input.readObject() as? PersistQueue
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun onCustomCommand(
        session: MediaSession,
        controller: MediaSession.ControllerInfo,
        customCommand: SessionCommand,
        args: Bundle,
    ): ListenableFuture<SessionResult> {
        when (customCommand.customAction) {
            MediaSessionConstants.ACTION_TOGGLE_LIKE -> toggleLike()
            MediaSessionConstants.ACTION_TOGGLE_START_RADIO -> toggleStartRadio()
            MediaSessionConstants.ACTION_TOGGLE_LIBRARY -> toggleLibrary()
            MediaSessionConstants.ACTION_TOGGLE_SHUFFLE -> session.player.shuffleModeEnabled =
                !session.player.shuffleModeEnabled

            MediaSessionConstants.ACTION_TOGGLE_REPEAT_MODE -> session.player.toggleRepeatMode()
        }
        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
    }

    override fun onGetLibraryRoot(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<MediaItem>> =
        Futures.immediateFuture(
            LibraryResult.ofItem(
                MediaItem
                    .Builder()
                    .setMediaId(MusicService.ROOT)
                    .setMediaMetadata(
                        MediaMetadata
                            .Builder()
                            .setIsPlayable(false)
                            .setIsBrowsable(true)
                            .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                            .setExtras(browsableExtras())
                            .build(),
                    ).build(),
                params,
            ),
        )

    override fun onSearch(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        query: String,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<Void>> =
        Futures.immediateFuture(LibraryResult.ofVoid(params)).also {
            val q = query.trim()
            pendingSearchJob?.cancel()
            pendingSearchJob =
                scope.launch(Dispatchers.IO) {
                    val count =
                        runCatching {
                            if (q.isBlank()) {
                                0
                            } else {
                                val localCount =
                                    searchOfflineSongs(q, previewSize = 25).count +
                                    database.searchArtistsCount(q) +
                                    database.searchAlbumsCount(q) +
                                    database.searchPlaylistsCount(q)
                                val onlineCount = searchOnlineSongs(q, previewSize = 25).size
                                localCount + onlineCount
                            }
                        }.getOrElse { 0 }
                    withContext(Dispatchers.Main) {
                        session.notifySearchResultChanged(browser, query, count, params)
                    }
                }
        }

    override fun onGetSearchResult(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        query: String,
        page: Int,
        pageSize: Int,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
        scope.future(Dispatchers.IO) {
            val q = query.trim()
            val safePage = page.coerceAtLeast(0)
            val safePageSize = pageSize.coerceIn(1, 50)
            if (q.isBlank()) {
                return@future LibraryResult.ofItemList(emptyList(), params)
            }

            val requested = (safePage + 1) * safePageSize
            val items = ArrayList<MediaItem>(min(requested, 200))

            val offlineSongs = searchOfflineSongs(q, previewSize = requested)
            val existingSongIds =
                offlineSongs.items
                    .mapTo(HashSet(offlineSongs.items.size * 2), ::searchSongIdentity)
            val onlineSongs =
                searchOnlineSongs(q, previewSize = requested).filter { onlineItem ->
                    existingSongIds.add(searchSongIdentity(onlineItem))
                }
            onlineSongs.forEach { onlineSearchItemCache[it.mediaId] = it }
            items +=
                interleaveMediaItems(
                    first = offlineSongs.items,
                    second = onlineSongs,
                ).take(requested)

            if (items.size < requested) {
                val remaining = requested - items.size

                val artists = database.searchArtists(q, previewSize = remaining).first()
                items +=
                    artists.map { artist ->
                        browsableMediaItem(
                            "${MusicService.ARTIST}/${artist.id}",
                            artist.title,
                            context.resources.getQuantityString(
                                R.plurals.n_song,
                                artist.songCount,
                                artist.songCount,
                            ),
                            artist.thumbnailUrl?.toUri(),
                            MediaMetadata.MEDIA_TYPE_ARTIST,
                        )
                    }
            }

            if (items.size < requested) {
                val remaining = requested - items.size

                val albums = database.searchAlbums(q, previewSize = remaining).first()
                items +=
                    albums.map { album ->
                        browsableMediaItem(
                            "${MusicService.ALBUM}/${album.id}",
                            album.title,
                            album.artists.joinToString { it.name },
                            album.thumbnailUrl?.toUri(),
                            MediaMetadata.MEDIA_TYPE_ALBUM,
                        )
                    }
            }

            if (items.size < requested) {
                val remaining = requested - items.size

                val playlists = database.searchPlaylists(q, previewSize = remaining).first()
                items +=
                    playlists.map { playlist ->
                        browsableMediaItem(
                            "${MusicService.PLAYLIST}/${playlist.id}",
                            playlist.title,
                            context.resources.getQuantityString(
                                R.plurals.n_song,
                                playlist.songCount,
                                playlist.songCount,
                            ),
                            playlist.thumbnails.firstOrNull()?.toUri(),
                            MediaMetadata.MEDIA_TYPE_PLAYLIST,
                        )
                    }
            }

            val from = safePage * safePageSize
            if (from >= items.size) return@future LibraryResult.ofItemList(emptyList(), params)
            val to = min(from + safePageSize, items.size)

            LibraryResult.ofItemList(items.subList(from, to), params)
        }

    override fun onGetChildren(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        parentId: String,
        page: Int,
        pageSize: Int,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
        scope.future(Dispatchers.IO) {
            LibraryResult.ofItemList(
                when (parentId) {
                    MusicService.ROOT ->
                        listOf(
                            browsableMediaItem(
                                MusicService.SONG,
                                context.getString(R.string.songs),
                                null,
                                drawableUri(R.drawable.music_note),
                                MediaMetadata.MEDIA_TYPE_PLAYLIST,
                            ),
                            browsableMediaItem(
                                MusicService.ARTIST,
                                context.getString(R.string.artists),
                                null,
                                drawableUri(R.drawable.artist),
                                MediaMetadata.MEDIA_TYPE_FOLDER_ARTISTS,
                            ),
                            browsableMediaItem(
                                MusicService.ALBUM,
                                context.getString(R.string.albums),
                                null,
                                drawableUri(R.drawable.album),
                                MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS,
                            ),
                            browsableMediaItem(
                                MusicService.PLAYLIST,
                                context.getString(R.string.playlists),
                                null,
                                drawableUri(R.drawable.queue_music),
                                MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS,
                            ),
                        )

                    MusicService.SONG -> database.songsByCreateDateAsc().first()
                        .map { it.toMediaItem(parentId) }

                    MusicService.ARTIST ->
                        database.artistsByCreateDateAsc().first().map { artist ->
                            browsableMediaItem(
                                "${MusicService.ARTIST}/${artist.id}",
                                artist.artist.name,
                                context.resources.getQuantityString(
                                    R.plurals.n_song,
                                    artist.songCount,
                                    artist.songCount
                                ),
                                artist.artist.thumbnailUrl?.toUri(),
                                MediaMetadata.MEDIA_TYPE_ARTIST,
                            )
                        }

                    MusicService.ALBUM ->
                        database.albumsByCreateDateAsc().first().map { album ->
                            browsableMediaItem(
                                "${MusicService.ALBUM}/${album.id}",
                                album.album.title,
                                album.artists.joinToString {
                                    it.name
                                },
                                album.album.thumbnailUrl?.toUri(),
                                MediaMetadata.MEDIA_TYPE_ALBUM,
                            )
                        }

                    MusicService.PLAYLIST -> {
                        val likedSongCount = database.likedSongsCount().first()
                        val downloadedSongCount = downloadUtil.downloads.value.size
                        listOf(
                            browsableMediaItem(
                                "${MusicService.PLAYLIST}/${PlaylistEntity.LIKED_PLAYLIST_ID}",
                                context.getString(R.string.liked_songs),
                                context.resources.getQuantityString(
                                    R.plurals.n_song,
                                    likedSongCount,
                                    likedSongCount
                                ),
                                drawableUri(R.drawable.favorite),
                                MediaMetadata.MEDIA_TYPE_PLAYLIST,
                            ),
                            browsableMediaItem(
                                "${MusicService.PLAYLIST}/${PlaylistEntity.DOWNLOADED_PLAYLIST_ID}",
                                context.getString(R.string.downloaded_songs),
                                context.resources.getQuantityString(
                                    R.plurals.n_song,
                                    downloadedSongCount,
                                    downloadedSongCount
                                ),
                                drawableUri(R.drawable.download),
                                MediaMetadata.MEDIA_TYPE_PLAYLIST,
                            ),
                        ) +
                                database.playlistsByCreateDateAsc().first().map { playlist ->
                                    browsableMediaItem(
                                        "${MusicService.PLAYLIST}/${playlist.id}",
                                        playlist.playlist.name,
                                        context.resources.getQuantityString(
                                            R.plurals.n_song,
                                            playlist.songCount,
                                            playlist.songCount
                                        ),
                                        playlist.thumbnails.firstOrNull()?.toUri(),
                                        MediaMetadata.MEDIA_TYPE_PLAYLIST,
                                    )
                                }
                    }

                    else ->
                        when {
                            parentId.startsWith("${MusicService.ARTIST}/") ->
                                database.artistSongsByCreateDateAsc(parentId.removePrefix("${MusicService.ARTIST}/"))
                                    .first().map {
                                    it.toMediaItem(parentId)
                                }

                            parentId.startsWith("${MusicService.ALBUM}/") ->
                                database.albumSongs(parentId.removePrefix("${MusicService.ALBUM}/"))
                                    .first().map {
                                    it.toMediaItem(parentId)
                                }

                            parentId.startsWith("${MusicService.PLAYLIST}/") ->
                                when (val playlistId =
                                    parentId.removePrefix("${MusicService.PLAYLIST}/")) {
                                    PlaylistEntity.LIKED_PLAYLIST_ID -> database.likedSongs(
                                        SongSortType.CREATE_DATE,
                                        true
                                    )

                                    PlaylistEntity.DOWNLOADED_PLAYLIST_ID -> {
                                        val downloads = downloadUtil.downloads.value
                                        database
                                            .allSongs()
                                            .flowOn(Dispatchers.IO)
                                            .map { songs ->
                                                songs.filter {
                                                    downloads[it.id]?.state == Download.STATE_COMPLETED
                                                }
                                            }.map { songs ->
                                                songs
                                                    .map { it to downloads[it.id] }
                                                    .sortedBy { it.second?.updateTimeMs ?: 0L }
                                                    .map { it.first }
                                            }
                                    }

                                    else ->
                                        database.playlistSongs(playlistId).map { list ->
                                            list.map { it.song }
                                        }
                                }.first().map {
                                    it.toMediaItem(parentId)
                                }

                            else -> emptyList()
                        }
                },
                params,
            )
        }

    override fun onGetItem(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        mediaId: String,
    ): ListenableFuture<LibraryResult<MediaItem>> =
        scope.future(Dispatchers.IO) {
            when {
                mediaId == MusicService.ROOT ->
                    LibraryResult.ofItem(
                        MediaItem
                            .Builder()
                            .setMediaId(MusicService.ROOT)
                            .setMediaMetadata(
                                MediaMetadata
                                    .Builder()
                                    .setIsPlayable(false)
                                    .setIsBrowsable(true)
                                    .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                                    .setExtras(browsableExtras())
                                    .build(),
                            ).build(),
                        null,
                    )

                mediaId == MusicService.SONG ->
                    LibraryResult.ofItem(
                        browsableMediaItem(
                            MusicService.SONG,
                            context.getString(R.string.songs),
                            null,
                            drawableUri(R.drawable.music_note),
                            MediaMetadata.MEDIA_TYPE_PLAYLIST,
                        ),
                        null,
                    )

                mediaId == MusicService.ARTIST ->
                    LibraryResult.ofItem(
                        browsableMediaItem(
                            MusicService.ARTIST,
                            context.getString(R.string.artists),
                            null,
                            drawableUri(R.drawable.artist),
                            MediaMetadata.MEDIA_TYPE_FOLDER_ARTISTS,
                        ),
                        null,
                    )

                mediaId == MusicService.ALBUM ->
                    LibraryResult.ofItem(
                        browsableMediaItem(
                            MusicService.ALBUM,
                            context.getString(R.string.albums),
                            null,
                            drawableUri(R.drawable.album),
                            MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS,
                        ),
                        null,
                    )

                mediaId == MusicService.PLAYLIST ->
                    LibraryResult.ofItem(
                        browsableMediaItem(
                            MusicService.PLAYLIST,
                            context.getString(R.string.playlists),
                            null,
                            drawableUri(R.drawable.queue_music),
                            MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS,
                        ),
                        null,
                    )

                mediaId.startsWith("${MusicService.SONG}/") ->
                    database.song(mediaId.removePrefix("${MusicService.SONG}/")).first()?.let {
                        LibraryResult.ofItem(it.toMediaItem(MusicService.SONG), null)
                    } ?: LibraryResult.ofError(SessionError.ERROR_UNKNOWN)

                mediaId.startsWith("${MusicService.ARTIST}/") ->
                    database.artist(mediaId.removePrefix("${MusicService.ARTIST}/")).first()?.let { artist ->
                        LibraryResult.ofItem(
                            browsableMediaItem(
                                "${MusicService.ARTIST}/${artist.id}",
                                artist.title,
                                context.resources.getQuantityString(
                                    R.plurals.n_song,
                                    artist.songCount,
                                    artist.songCount,
                                ),
                                artist.thumbnailUrl?.toUri(),
                                MediaMetadata.MEDIA_TYPE_ARTIST,
                            ),
                            null,
                        )
                    } ?: LibraryResult.ofError(SessionError.ERROR_UNKNOWN)

                mediaId.startsWith("${MusicService.ALBUM}/") ->
                    database.album(mediaId.removePrefix("${MusicService.ALBUM}/")).first()?.let { album ->
                        LibraryResult.ofItem(
                            browsableMediaItem(
                                "${MusicService.ALBUM}/${album.id}",
                                album.title,
                                album.artists.joinToString { it.name },
                                album.thumbnailUrl?.toUri(),
                                MediaMetadata.MEDIA_TYPE_ALBUM,
                            ),
                            null,
                        )
                    } ?: LibraryResult.ofError(SessionError.ERROR_UNKNOWN)

                mediaId.startsWith("${MusicService.PLAYLIST}/") ->
                    database.playlist(mediaId.removePrefix("${MusicService.PLAYLIST}/")).first()?.let { playlist ->
                        LibraryResult.ofItem(
                            browsableMediaItem(
                                "${MusicService.PLAYLIST}/${playlist.id}",
                                playlist.title,
                                context.resources.getQuantityString(
                                    R.plurals.n_song,
                                    playlist.songCount,
                                    playlist.songCount,
                                ),
                                playlist.thumbnails.firstOrNull()?.toUri(),
                                MediaMetadata.MEDIA_TYPE_PLAYLIST,
                            ),
                            null,
                        )
                    } ?: LibraryResult.ofError(SessionError.ERROR_UNKNOWN)

                else ->
                    onlineSearchItemCache[mediaId]?.let {
                        LibraryResult.ofItem(it, null)
                    } ?: database.song(mediaId).first()?.toMediaItem()?.let {
                        LibraryResult.ofItem(it, null)
                    } ?: LibraryResult.ofError(SessionError.ERROR_UNKNOWN)
            }
        }

    override fun onSetMediaItems(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo,
        mediaItems: MutableList<MediaItem>,
        startIndex: Int,
        startPositionMs: Long,
    ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> =
        scope.future {
            // Play from Android Auto
            val defaultResult =
                MediaSession.MediaItemsWithStartPosition(emptyList(), startIndex, startPositionMs)
            val firstItem = mediaItems.firstOrNull() ?: return@future defaultResult
            val voiceQuery = firstItem.requestMetadata.searchQuery?.trim().orEmpty()
            if (voiceQuery.isNotBlank()) {
                val offlineSongs = searchOfflineSongs(voiceQuery, previewSize = 50)
                val existingSongIds =
                    offlineSongs.items.mapTo(HashSet(offlineSongs.items.size * 2), ::searchSongIdentity)
                val onlineSongs =
                    searchOnlineSongs(voiceQuery, previewSize = 50).filter { onlineItem ->
                        existingSongIds.add(searchSongIdentity(onlineItem))
                    }
                val searchQueue = interleaveMediaItems(offlineSongs.items, onlineSongs)
                if (searchQueue.isNotEmpty()) {
                    return@future MediaSession.MediaItemsWithStartPosition(
                        searchQueue,
                        0,
                        startPositionMs,
                    )
                }
            }
            val path = firstItem.mediaId.split("/").filter { it.isNotBlank() }
            when (path.firstOrNull()) {
                MusicService.SONG -> {
                    val songId = path.getOrNull(1) ?: return@future defaultResult
                    val allSongs = database.songsByCreateDateAsc().first()
                    MediaSession.MediaItemsWithStartPosition(
                        allSongs.map { it.toMediaItem() },
                        allSongs.indexOfFirst { it.id == songId }.takeIf { it != -1 } ?: 0,
                        startPositionMs,
                    )
                }

                MusicService.ARTIST -> {
                    val songId = path.getOrNull(2) ?: return@future defaultResult
                    val artistId = path.getOrNull(1) ?: return@future defaultResult
                    val songs = database.artistSongsByCreateDateAsc(artistId).first()
                    MediaSession.MediaItemsWithStartPosition(
                        songs.map { it.toMediaItem() },
                        songs.indexOfFirst { it.id == songId }.takeIf { it != -1 } ?: 0,
                        startPositionMs,
                    )
                }

                MusicService.ALBUM -> {
                    val songId = path.getOrNull(2) ?: return@future defaultResult
                    val albumId = path.getOrNull(1) ?: return@future defaultResult
                    val albumWithSongs =
                        database.albumWithSongs(albumId).first() ?: return@future defaultResult
                    MediaSession.MediaItemsWithStartPosition(
                        albumWithSongs.songs.map { it.toMediaItem() },
                        albumWithSongs.songs.indexOfFirst { it.id == songId }.takeIf { it != -1 }
                            ?: 0,
                        startPositionMs,
                    )
                }

                MusicService.PLAYLIST -> {
                    val songId = path.getOrNull(2) ?: return@future defaultResult
                    val playlistId = path.getOrNull(1) ?: return@future defaultResult
                    val songs =
                        when (playlistId) {
                            PlaylistEntity.LIKED_PLAYLIST_ID -> database.likedSongs(
                                SongSortType.CREATE_DATE,
                                descending = true
                            )

                            PlaylistEntity.DOWNLOADED_PLAYLIST_ID -> {
                                val downloads = downloadUtil.downloads.value
                                database
                                    .allSongs()
                                    .flowOn(Dispatchers.IO)
                                    .map { songs ->
                                        songs.filter {
                                            downloads[it.id]?.state == Download.STATE_COMPLETED
                                        }
                                    }.map { songs ->
                                        songs
                                            .map { it to downloads[it.id] }
                                            .sortedBy { it.second?.updateTimeMs ?: 0L }
                                            .map { it.first }
                                    }
                            }

                            else ->
                                database.playlistSongs(playlistId).map { list ->
                                    list.map { it.song }
                                }
                        }.first()
                    MediaSession.MediaItemsWithStartPosition(
                        songs.map { it.toMediaItem() },
                        songs.indexOfFirst { it.id == songId }.takeIf { it != -1 } ?: 0,
                        startPositionMs,
                    )
                }

                else -> {
                    val directMediaId = firstItem.mediaId.trim()
                    if (directMediaId.isNotBlank() && !directMediaId.contains("/")) {
                        val selectedItem = onlineSearchItemCache[directMediaId] ?: firstItem
                        return@future MediaSession.MediaItemsWithStartPosition(
                            listOf(selectedItem),
                            0,
                            startPositionMs,
                        )
                    }

                    val query = firstItem.requestMetadata.searchQuery?.trim().orEmpty()
                    if (query.isBlank()) return@future defaultResult

                    val matchedSongs = database.searchSongs(query, previewSize = 50).first()
                    val songId = matchedSongs.firstOrNull()?.id ?: return@future defaultResult
                    val allSongs = database.songsByCreateDateAsc().first()
                    MediaSession.MediaItemsWithStartPosition(
                        allSongs.map { it.toMediaItem() },
                        allSongs.indexOfFirst { it.id == songId }.takeIf { it != -1 } ?: 0,
                        startPositionMs,
                    )
                }
            }
        }

    private fun drawableUri(
        @DrawableRes id: Int,
    ) = Uri
        .Builder()
        .scheme(ContentResolver.SCHEME_ANDROID_RESOURCE)
        .authority(context.resources.getResourcePackageName(id))
        .appendPath(context.resources.getResourceTypeName(id))
        .appendPath(context.resources.getResourceEntryName(id))
        .build()

    private fun browsableMediaItem(
        id: String,
        title: String,
        subtitle: String?,
        iconUri: Uri?,
        mediaType: Int = MediaMetadata.MEDIA_TYPE_MUSIC,
    ) = MediaItem
        .Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata
                .Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setArtist(subtitle)
                .setArtworkUri(iconUri)
                .setIsPlayable(false)
                .setIsBrowsable(true)
                .setMediaType(mediaType)
                .setExtras(browsableExtras())
                .build(),
        ).build()

    private fun Song.toMediaItem(path: String) =
        MediaItem
            .Builder()
            .setMediaId("$path/$id")
            .setMediaMetadata(
                MediaMetadata
                    .Builder()
                    .setTitle(song.title)
                    .setSubtitle(artists.joinToString { it.name })
                    .setArtist(artists.joinToString { it.name })
                    .setArtworkUri(song.thumbnailUrl?.toUri())
                    .setIsPlayable(true)
                    .setIsBrowsable(false)
                    .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                    .setExtras(playableExtras())
                    .build(),
            ).build()

    private data class OfflineSongSearchResult(
        val items: List<MediaItem>,
        val count: Int,
    )

    private suspend fun searchOfflineSongs(
        query: String,
        previewSize: Int,
    ): OfflineSongSearchResult {
        if (query.isBlank() || previewSize <= 0) {
            return OfflineSongSearchResult(
                items = emptyList(),
                count = 0,
            )
        }

        val librarySongs = database.searchSongs(query, previewSize = previewSize).first()
        val libraryIds = librarySongs.mapTo(HashSet(librarySongs.size)) { it.id }
        val cachedOnlySongs = searchCachedOnlySongs(query, excludeIds = libraryIds)

        return OfflineSongSearchResult(
            items =
                interleaveMediaItems(
                    first = librarySongs.map { it.toMediaItem(MusicService.SONG) },
                    second = cachedOnlySongs.take(previewSize).map { it.toMediaItem() },
                ).take(previewSize),
            count = database.searchSongsCount(query) + cachedOnlySongs.size,
        )
    }

    private suspend fun searchCachedOnlySongs(
        query: String,
        excludeIds: Set<String> = emptySet(),
    ): List<Song> {
        val cachedIds = cachedSongIds()
        if (cachedIds.isEmpty()) return emptyList()

        val normalizedQuery = query.lowercase(Locale.getDefault())
        return database
            .getSongsByIds(cachedIds)
            .asSequence()
            .filter { it.song.inLibrary == null }
            .filterNot { it.id in excludeIds }
            .filter { it.song.title.lowercase(Locale.getDefault()).contains(normalizedQuery) }
            .sortedBy { it.song.title.lowercase(Locale.getDefault()) }
            .toList()
    }

    private fun cachedSongIds(): List<String> {
        val completedDownloadIds =
            downloadUtil.downloads.value
                .asSequence()
                .filter { (_, download) -> download.state == Download.STATE_COMPLETED }
                .map { (id, _) -> id }
        val downloadCacheIds =
            runCatching { downloadUtil.downloadCache.keys.asSequence() }
                .getOrDefault(emptySequence())
        val playerCacheIds =
            runCatching { downloadUtil.playerCache.keys.asSequence() }
                .getOrDefault(emptySequence())

        return sequenceOf(completedDownloadIds, downloadCacheIds, playerCacheIds)
            .flatten()
            .map(String::trim)
            .filter(String::isNotBlank)
            .distinct()
            .toList()
    }

    private fun interleaveMediaItems(
        first: List<MediaItem>,
        second: List<MediaItem>,
    ): List<MediaItem> {
        if (first.isEmpty()) return second
        if (second.isEmpty()) return first

        val merged = ArrayList<MediaItem>(first.size + second.size)
        val maxSize = maxOf(first.size, second.size)
        repeat(maxSize) { index ->
            first.getOrNull(index)?.let(merged::add)
            second.getOrNull(index)?.let(merged::add)
        }
        return merged
    }

    private fun searchSongIdentity(item: MediaItem): String =
        item.mediaId.removePrefix("${MusicService.SONG}/")

    private suspend fun searchOnlineSongs(
        query: String,
        previewSize: Int,
    ): List<MediaItem> {
        if (query.isBlank() || previewSize <= 0) return emptyList()
        return YouTube
            .search(query, YouTube.SearchFilter.FILTER_SONG)
            .getOrNull()
            ?.items
            .orEmpty()
            .asSequence()
            .filterIsInstance<SongItem>()
            .distinctBy { it.id }
            .take(previewSize)
            .map { it.toMediaItem() }
            .toList()
    }

    companion object {
        private const val EXTRA_CONTENT_STYLE_SUPPORTED = "android.media.browse.CONTENT_STYLE_SUPPORTED"
        private const val EXTRA_CONTENT_STYLE_BROWSABLE_HINT =
            "android.media.browse.CONTENT_STYLE_BROWSABLE_HINT"
        private const val EXTRA_CONTENT_STYLE_PLAYABLE_HINT =
            "android.media.browse.CONTENT_STYLE_PLAYABLE_HINT"

        private const val CONTENT_STYLE_LIST_ITEM = 1
        private const val CONTENT_STYLE_GRID_ITEM = 2
    }
}
