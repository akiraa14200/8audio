<div align="center">

  <img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/icon.png" width="160" height="160" alt="ArchiveTune Logo" style="border-radius: 22%">

  <h1>ArchiveTune</h1>

  <p align="center">
    <strong>Redefining the YouTube Music Experience on Android.</strong>
    <br />
    <em>It’s high-performance, privacy-focused, and packed with features for people who really care about their experience.</em>
  </p>

  <p align="center">
    <a href="https://archivetune.koiiverse.cloud"><b>Official Website</b></a> •
    <a href="#features"><b>Features</b></a> •
    <a href="PRIVACY.md"><b>Privacy</b></a> •
    <a href="#download-now"><b>Download</b></a> •
    <a href="#screenshots"><b>Screenshots</b></a> •
    <a href="https://github.com/koiverse/ArchiveTune/issues/new/choose"><b>Support</b></a>
  </p>

  <div align="center">
    <img src="https://img.shields.io/github/v/release/koiverse/ArchiveTune?style=for-the-badge&color=6366f1&labelColor=1e1e2e&logo=github" alt="Latest Version" />
    <img src="https://img.shields.io/github/downloads/koiverse/ArchiveTune/total?style=for-the-badge&color=6366f1&labelColor=1e1e2e&logo=github" alt="Downloads" />
    <img src="https://img.shields.io/github/stars/koiverse/ArchiveTune?style=for-the-badge&color=6366f1&labelColor=1e1e2e&logo=github" alt="Stars" />
    <img src="https://img.shields.io/github/license/koiverse/ArchiveTune?style=for-the-badge&color=6366f1&labelColor=1e1e2e" alt="License" />
    <img src="https://img.shields.io/badge/Architecture-MVVM-6366f1?style=for-the-badge&labelColor=1e1e2e&logo=kotlin" alt="MVVM Architecture" />
    <img src="https://img.shields.io/badge/Language-Kotlin-7f52ff?style=for-the-badge&logo=kotlin&color=6366f1&labelColor=1e1e2e" alt="Kotlin Language" />
    <img src="https://img.shields.io/badge/Toolkit-Jetpack_Compose-4285f4?style=for-the-badge&logo=jetpack-compose&color=6366f1&labelColor=1e1e2e" alt="Jetpack Compose Toolkit" />
    <img src="https://img.shields.io/badge/Design-Material_3-000000?style=for-the-badge&logo=material-design&color=6366f1&labelColor=1e1e2e" alt="Material Design 3" />
    <a href="https://t.me/ArchiveTuneGC"><img src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white" alt="Telegram" /></a>
  </div>
  
  <br />

  <a href="https://trendshift.io/repositories/17521" target="_blank">
    <img src="https://trendshift.io/api/badge/repositories/17521" alt="ArchiveTune | Trendshift" style="width: 250px; height: 55px;" width="250" height="55"/>
  </a>
</div>

<hr />

**ArchiveTune** isn’t just another generic YouTube Music wrapper. It’s a fully custom-built player made from the ground up, because we think your music should stay private, look clean, and work exactly the way you expect. If you care about sound quality and want something that actually feels good to use, this is it.

---

> [!IMPORTANT]  
> **Geographic Availability:** If YouTube Music is not supported in your region, a VPN or proxy set to a supported region is required for initial data fetching.

---

## 📸 Showcase

<div align="center">

<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_1.jpg" alt="Browse" width="30%" />
<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_2.jpg" alt="Live Lyrics" width="30%" />
<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_3.jpg" alt="Theme Customization" width="30%" />
<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_4.jpg" alt="Live Statistics" width="30%" />
<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_5.jpg" alt="Artist" width="30%" />
<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_6.jpg" alt="Album" width="30%" />
<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_7.jpg" alt="Player" width="30%" />
<img src="https://github.com/koiverse/ArchiveTune/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot_8.jpg" alt="Settings" width="30%" />

</div>

---

## ✨ Features

<div align="center">

<table>
  <tr>
    <td width="50%" valign="top">
      <div align="left">
        <h3>Playback</h3>
        <ul>
          <li>Ad-free playback with background listening</li>
          <li>Your playlists, liked songs, and subscriptions appear after sign-in</li>
          <li>Support local file and local song playback
          <li>Fast startup and lightweight performance</li>
          <li>Built for a private, uninterrupted listening experience</li>
        </ul>
      </div>
    </td>
    <td width="50%" valign="top">
      <div align="left">
        <h3>Audio</h3>
        <ul>
          <li>EBU R128 loudness normalization</li>
          <li>Tempo, pitch, and playback speed controls</li>
          <li>Crossfade between tracks</li>
          <li>System equalizer and spatial audio integration</li>
        </ul>
      </div>
    </td>
  </tr>
  <tr>
    <td width="50%" valign="top">
      <div align="left">
        <h3>Lyrics &amp; Discovery</h3>
        <ul>
          <li>Live synced lyrics</li>
          <li>Lyrics translation and romanization</li>
          <li>Music recognition for songs around you</li>
          <li>Listening statistics whenever you want them</li>
        </ul>
      </div>
    </td>
    <td width="50%" valign="top">
      <div align="left">
        <h3>Sync &amp; Social</h3>
        <ul>
          <li>YouTube Music account integration</li>
          <li>Last.fm scrobbling</li>
          <li>ListenBrainz history sync</li>
          <li>Discord rich presence support</li>
        </ul>
      </div>
    </td>
  </tr>
  <tr>
    <td width="50%" valign="top">
      <div align="left">
        <h3>Interface</h3>
        <ul>
          <li>Material 3 design language</li>
          <li>Album-art powered dynamic colors</li>
          <li>Responsive layouts for different screen sizes</li>
          <li>Clean browsing, player, artist, album, and lyrics views</li>
        </ul>
      </div>
    </td>
    <td width="50%" valign="top">
      <div align="left">
        <h3>Customization</h3>
        <ul>
          <li>Deep playback and interface settings</li>
          <li>Gesture customization</li>
          <li>Animation and layout tuning</li>
          <li>Flexible controls to shape the app around your workflow</li>
        </ul>
      </div>
    </td>
  </tr>
</table>

</div>

---

## 📥 Download Now

<div align="center">

<h2>Stable Release</h2>

<table>
  <thead>
    <tr>
      <th align="center">Obtainium</th>
      <th align="center">IzzyOnDroid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td align="center">
        <a href="https://apps.obtainium.imranr.dev/redirect?r=obtainium://add/https://github.com/koiverse/ArchiveTune/">
          <img src="https://github.com/ImranR98/Obtainium/blob/main/assets/graphics/badge_obtainium.png" height="50" alt="Get ArchiveTune on Obtainium">
        </a>
      </td>
      <td align="center">
        <a href="https://apt.izzysoft.de/fdroid/index/apk/moe.koiverse.archivetune">
          <img src="https://raw.githubusercontent.com/koiverse/ArchiveTune/757d5932832e1da27ced56de98c5ad1275cf0db1/assets/IzzyOnDroidButtonBorder.svg" height="50" alt="Get ArchiveTune on IzzyOnDroid">
        </a>
      </td>
    </tr>
    <tr>
      <th align="center" colspan="2">GitHub</th>
    </tr>
    <tr>
      <td align="center" colspan="2">
        <a href="https://github.com/koiverse/ArchiveTune/releases/latest">
          <img src="https://raw.githubusercontent.com/koiverse/ArchiveTune/refs/heads/main/assets/badge_github.png" height="50" alt="Get ArchiveTune on GitHub">
        </a>
      </td>
    </tr>
    <tr>
      <th align="center">OpenAPK</th>
      <th align="center">Unclouded</th>
    </tr>
    <tr>
      <td align="center">
        <a href="https://www.openapk.net/archivetune/moe.koiverse.archivetune/">
          <img src="https://www.openapk.net/images/openapk-badge.png" height="75" alt="Get ArchiveTune on OpenAPK">
        </a>
      </td>
      <td align="center">
        <a href="https://unclouded.app/apps/archivetune/">
          <img src="https://raw.githubusercontent.com/koiverse/ArchiveTune/refs/heads/dev/assets/badge_unclouded.png" height="50" alt="Get ArchiveTune on Unclouded">
        </a>
      </td>
    </tr>
  </tbody>
</table>

<h2>Nightly Build</h2>

<table>
  <thead>
    <tr>
      <th align="center">GitHub Actions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td align="center">
        <a href="https://nightly.link/koiverse/ArchiveTune/workflows/build/dev/app-universal-release">
          <img src="https://raw.githubusercontent.com/koiverse/ArchiveTune/refs/heads/main/assets/badge_github.png" height="50" alt="Download the latest ArchiveTune nightly build">
        </a>
      </td>
    </tr>
  </tbody>
</table>
</div>

> [!WARNING]  
> **Notes:** The trusted download source is listed above; we are not responsible for any risks you may encounter from downloading from other sources.

## ❓ Need Help or Have Questions?
Join Our Telegram Channels for Support and Discussion.

[![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/ArchiveTuneGC)

---

## 🌍 Globalization

ArchiveTune belongs to everyone. Help us localize the experience for your region.

[![Static Badge](https://img.shields.io/badge/translate-help?style=for-the-badge&logo=weblate&labelColor=grey)](https://translate.codeberg.org/engage/archivetune/)

<div align="center">
  <a href="https://translate.codeberg.org/engage/archivetune/">
    <img src="https://translate.codeberg.org/widget/archivetune/horizontal-blue.svg" alt="Translation status" />
  </a>
</div>

### ✨ Project Contributors
<a href="https://github.com/koiverse/ArchiveTune/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=koiverse/ArchiveTune" />
</a>

### 🛠️ Development & Engineering
Interested in building the project or contributing? ArchiveTune is built on a high-performance Kotlin stack.
<a href="CONTRIBUTING.md"><b>Read the Build & Contribution Guide →</b></a>

---

### ⭐ Support the Project
ArchiveTune is free and open-source. If it brings you joy, consider supporting its development!
##### Tribe
<a href="https://sociabuzz.com/chrtrxwstia">
  <img src="https://github.com/koiverse/ArchiveTune/blob/dev/assets/tribe.png?raw=true" alt="Buy Me a Coffee" width="160" />
</a>

---

## 🤝 Acknowledgments

We stand on the shoulders of open-source giants:
- **Metrolist** by [Mostafa Alagamy](https://github.com/mostafaalagamy/Metrolist) For Base framework.
- **Kizzy** by [dead8309](https://github.com/dead8309/Kizzy) For Discord Integration.
- **SimpMusic** by [maxrave-dev](https://github.com/maxrave-dev/SimpMusic) For Lyrics API Provider.
- [BetterLyrics](https://better-lyrics.boidu.dev/) For word-by-word Lyrics API Provider & Artwork Provider.
- [Material Color Utilities](https://github.com/material-foundation/material-color-utilities)
- [Read You](https://github.com/Ashinch/ReadYou) and [Seal](https://github.com/JunkFood02/Seal) for Ui Components.
- The global community of translators and beta testers.

---

## ⚖️ Legal Disclaimer

ArchiveTune is an independent third-party client.
- Not affiliated with Google LLC or YouTube.
- Does not bypass YouTube's technical protections.
- Users are encouraged to support artists by purchasing music via official channels.

---

<div align="center">
  <img src="https://raw.githubusercontent.com/koiverse/ArchiveTune/refs/heads/dev/fastlane/metadata/android/en-US/images/ArchiveTuneFull.png" alt="ArchiveTune Banner" style="width: 100%; max-width: 500px;">
  <p><b>If ArchiveTune elevated your music experience, please consider giving us a ⭐</b></p>
  <br />
  <img src="https://raw.githubusercontent.com/koiverse/ArchiveTune/refs/heads/dev/assets/badge_part.png" alt="ArchiveTune Banner" style="width: 160px">
</div>
